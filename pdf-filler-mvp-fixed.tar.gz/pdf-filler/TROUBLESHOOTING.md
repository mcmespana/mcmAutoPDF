# 🔧 Solución de Problemas - Deploy

## ❌ Error: ModuleNotFoundError: pypdf

**Síntoma:**
```
ModuleNotFoundError: No module named 'pypdf'
```

**Causa:** 
Streamlit Cloud a veces tiene problemas con `pypdf`. Usamos `PyPDF2` en su lugar.

**Solución (YA APLICADA):**
✅ El proyecto ahora usa `PyPDF2>=3.0.0` en vez de `pypdf`
✅ Los imports están actualizados
✅ El código es compatible

---

## 🚀 Deploy en Streamlit Cloud

### Paso a paso:

1. **Sube el código a GitHub**
   ```bash
   git init
   git add .
   git commit -m "PDF Filler - Fixed PyPDF2"
   git remote add origin https://github.com/TU_USUARIO/pdf-filler.git
   git push -u origin main
   ```

2. **Ve a [share.streamlit.io](https://share.streamlit.io)**

3. **Conecta tu repo:**
   - Repository: `TU_USUARIO/pdf-filler`
   - Branch: `main`
   - Main file path: `app.py`

4. **Deploy!** 🎉

---

## ⚙️ Configuración avanzada (opcional)

Si sigues teniendo problemas, prueba con estas versiones específicas:

**requirements.txt:**
```txt
streamlit==1.28.0
PyPDF2==3.0.1
pandas==2.0.3
```

---

## 🐛 Otros errores comunes

### Error: "File size too large"
**Solución:** Streamlit Cloud tiene límite de 50MB por archivo.
- Sube PDFs más pequeños
- O procesa localmente

### Error: "Permission denied"
**Solución:** El app usa archivos temporales.
- Ya está configurado para usar `/tmp/` en Streamlit Cloud
- No requiere cambios

### Error: "Missing fields"
**Solución:** 
- Asegúrate de que tu PDF tiene campos interactivos
- Usa `python test.py tu_pdf.pdf` localmente para verificar

---

## ✅ Checklist de Deploy

- [ ] `requirements.txt` actualizado con PyPDF2
- [ ] Código pusheado a GitHub
- [ ] App conectada en Streamlit Cloud
- [ ] Primera prueba con PDF simple

---

## 📞 Si nada funciona

**Plan B: Deploy local**
```bash
# En tu máquina o servidor
streamlit run app.py --server.port 8501 --server.address 0.0.0.0
```

Accesible en: `http://TU_IP:8501`

---

**Versión actualizada:** Noviembre 2025
**Compatible con:** Streamlit Cloud, Python 3.8+
